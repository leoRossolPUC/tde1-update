public class Nodos {

    int nota;
    Nodos esq, dir, cen;
    boolean isLeaf;

    public Nodos (int nota){
        this.nota=nota;
        this.cen=null;
        this.dir=null;
        this.esq=null;
        this.isLeaf=false;
    }


    // Método recursivo para imprimir a árvore em pré-ordem
    public void printArvore() {
        // Imprime o nó atual
        System.out.print("Nó: " + this.nota + " ");

        // Verifica se há filhos à esquerda, meio ou direita, e imprime recursivamente
        if (this.esq != null) {
            System.out.print("-> Filho à esquerda: ");
            this.esq.printArvore();  // Chamada recursiva para o filho à esquerda
        }

        if (this.cen != null) {
            System.out.print("-> Filho ao meio: ");
            this.cen.printArvore();  // Chamada recursiva para o filho ao meio
        }

        if (this.dir != null) {
            System.out.print("-> Filho à direita: ");
            this.dir.printArvore();  // Chamada recursiva para o filho à direita
        }

        // Para facilitar a leitura na saída
        System.out.println();
    }
}

