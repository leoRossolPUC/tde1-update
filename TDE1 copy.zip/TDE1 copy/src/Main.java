public class Main {
    public static void main(String[] args) {
        // Defina o caminho do arquivo de teste
        String pathTESTE = "src/casosTeste/casod30.txt";
        // Inicializa o leitor para ler o arquivo e processar a árvore
        try {
            // Lê o arquivo, preenche a matriz e cria os nós
            Leitor leitor = new Leitor(pathTESTE);

            // Encontra a raiz da árvore
            Nodos raiz = leitor.encontrarRaiz(leitor.temp, leitor.matriz, leitor.linhas, leitor.colunas);

            // Verifica se a raiz foi encontrada e imprime a árvore
            if (raiz != null) {
                System.out.println("Árvore:");
                raiz.printArvore();  // Imprime a árvore em pré-ordem
            } else {
                System.out.println("Não foi possível encontrar a raiz da árvore.");
            }

        } catch (Exception e) {
            System.out.println("Erro ao processar o arquivo: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
