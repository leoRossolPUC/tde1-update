import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.Buffer;

public class Leitor {
    public Nodos[][] temp;

    //cada caso de teste apresenta dois numeros representando linhas e colunas
    //usando esses, podemos imaginar que a arvore esta num grid, como batalha naval
    //devemos ler todas as linhas e colunas
    //  \|/ representam para onde estao os filhos
    //  v w representam bifurcacoes
    //  numeros = nodo
    //  # = folha = fim
    //


    //ler primeiros dois numeros e entao conseguir o tamanho da matriz x,y
    //pular para proxima linha
    //ler cada espaco da matriz, identificando o caractere
    //por exemplo, se x=30, tem que ler pelo menos 30 vezes na vertical
    //processar o que tem em cada espaco
        //se for espaco pula pro proximo
        // \|/ direcao de onde esta o filho
        // v w bifurcacao
        // numero = nodo
    //criar nodos a partir dissoa


    int linhas, colunas;
    char [][] matriz;


    public Leitor (String pathTESTE){
        try (BufferedReader br = new BufferedReader(new FileReader(pathTESTE))){

            //le os dois primeiros numeros (x,y)
            String[] param = br.readLine().split(" ");
            linhas = Integer.parseInt(param[0]);
            colunas = Integer.parseInt(param[1]);

            //incializa o grid com os numeros de linhas e colunas
            matriz = new char [linhas] [colunas];

            //armazenamento temporario
            Nodos [][] temp = new Nodos[linhas][colunas];

            //percorre todos os espacos da matriz
            for (int i=0; i<linhas; i++) {
                String linha = br.readLine();
                if (linha != null && linha.length() >= colunas) {
                    for (int j=0; j<colunas; j++) {
                        matriz[i][j] = linha.charAt(j);

                        //cria um nodo temporario quando acha um numero
                        if (Character.isDigit(matriz[i][j])){
                            int nota = Character.getNumericValue(matriz[i][j]);
                            temp [i][j] = new Nodos(nota);
                        }

                    }
                }
            }

            //percorremos a matriz novamente para conectar os nos agora
            for (int i=0; i<linhas; i++){
                for (int j=0; j<colunas; j++){

                    //verifica se a posicao atual possui um no
                    //se tiver, vai verificar as direcoes dos filhos

                    //verifica se ha filhos a esquerda
                    if (i>0 && j>0 && matriz[i-1][j-1] == '\\'){
                        temp[i][j].esq = temp[i-1][j-1]; //filho a esquerda
                    }

                    //verifica se ha filhos ao centro
                    if (i>0 && matriz[i-1][j] == '|'){
                        temp[i][j].cen = temp[i-1][j]; //filho ao meio
                    }

                    //verifica se ha filhos a direita
                    if (i>0 && j<colunas-1 && matriz[i-1][j+1] == '/'){
                        temp[i][j].dir = temp[i-1][j+1]; //filho a direita
                    }


                    //verifica se e uma bifurcacao V
                    if (matriz[i][j] == 'V') {
                        //conecta o filho da esquerda e direita
                        if (i > 0 && j > 0 && matriz[i - 1][j - 1] == '\\') {
                            temp[i][j].esq = temp[i - 1][j - 1]; //filho a esquerda
                        }

                        if (i>0 && j<colunas-1 && matriz[i-1][j+1] == '/'){
                            temp[i][j].dir = temp[i-1][j+1]; //filho a direita
                        }
                    }

                    //verifica se e uma bifurcacao W
                    if (matriz[i][j] == 'W'){
                        //conecta os filhos em todaas as direcoes
                        if (i>0 && j>0 && matriz[i-1][j-1] == '\\'){
                            temp[i][j].esq = temp[i-1][j-1]; //filho a esquerda
                        }

                        if (i>0 && matriz[i-1][j] == '|'){
                            temp[i][j].cen = temp[i-1][j]; //filho ao meio
                        }

                        if (i>0 && j<colunas-1 && matriz[i-1][j+1] == '/'){
                            temp[i][j].dir = temp[i-1][j+1]; //filho a direita
                        }
                    }
                }
            }


            Nodos raiz = encontrarRaiz(temp, matriz, linhas, colunas);
            if (raiz != null){
                raiz.printArvore();
            } else {
                System.out.println("kkkkk se fode ai");
            }

        //excecoes etc...
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    //ENCONTRADOR DE RAIZ
    public Nodos encontrarRaiz(Nodos[][] temp, char[][] matriz, int linhas, int colunas) {
        // Percorre a última linha para encontrar um nó que tenha conexões ascendentes
        for (int j=0; j<colunas; j++) {
            if (temp[linhas-1][j] != null) {  // Se houver um nó nesta posição

                // Verifica se o nó tem uma conexão para cima na linha anterior
                if (linhas > 1 && (matriz[linhas-2][j] == '|' ||
                        (j>0 && matriz[linhas-2][j-1] == '\\') ||
                        (j<colunas - 1 && matriz[linhas-2][j+1] == '/'))) {
                    return temp[linhas-1][j];  // Retorna o nó como a raiz
                }
            }
        }
        // Se não encontrar, retorna null (a árvore não foi identificada corretamente)
        return null;
    }







    public void imprimir(){
        for (int i=0; i<linhas; i++){
            for (int j=0; j<colunas; j++){
                System.out.println(matriz[i][j]);
            }
            System.out.println();
        }
    }

}
